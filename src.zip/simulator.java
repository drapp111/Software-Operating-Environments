public class simulator
{
	public static void main(String[] args)
	{
		simEnv env = new simEnv();
	}
}
